namespace SWL.App.Ports
{
    public interface IConnectivityService
    {

    }
}