namespace SWL.App.Ports
{
    public interface ILeaderboardService
    {

    }
}