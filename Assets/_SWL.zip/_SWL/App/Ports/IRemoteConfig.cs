namespace SWL.App.Ports
{
    public interface IRemoteConfig
    {

    }
}