namespace SWL.App.Ports
{
    public interface IIapService
    {

    }
}