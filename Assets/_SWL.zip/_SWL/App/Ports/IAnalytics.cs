namespace SWL.App.Ports
{
    public interface IAnalytics
    {

    }
}