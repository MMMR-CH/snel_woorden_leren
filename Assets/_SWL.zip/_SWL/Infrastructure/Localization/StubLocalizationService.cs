namespace SWL.Infrastructure
{
    public class StubLocalizationService
    {

    }
}