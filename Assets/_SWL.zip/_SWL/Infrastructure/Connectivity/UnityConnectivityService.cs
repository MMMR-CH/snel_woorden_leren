namespace SWL.App.Infrastructure
{
    public class UnityConnectivityService 
    {
    }
}