namespace SWL.Infrastructure
{
    public class StubRemoteConfig
    {

    }
}