namespace SWL.Infrastructure
{
    public class StubLeaderboardService
    {
        
    }
}