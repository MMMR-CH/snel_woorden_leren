namespace SWL.Infrastructure
{
    public class StubIapService
    {

    }
}