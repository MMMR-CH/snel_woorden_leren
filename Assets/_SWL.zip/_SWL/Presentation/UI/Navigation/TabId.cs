namespace SWL.Presentation.UI.Navigation
{
    public enum TabId
    {
        Settings = 0,
        Shop = 1,
        Home = 2,
        League = 3,
        Words = 4
    }
}
