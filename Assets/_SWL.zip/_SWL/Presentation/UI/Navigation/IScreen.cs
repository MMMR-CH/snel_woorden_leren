namespace SWL.Presentation.UI.Navigation
{
    public interface IScreen
    {
        void Show();
        void Hide();
    }
}
