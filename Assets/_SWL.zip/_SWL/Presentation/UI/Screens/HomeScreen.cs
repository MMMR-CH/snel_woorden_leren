using SWL.Presentation.UI.Navigation;

namespace SWL.Presentation.UI.Screens
{
    public sealed class HomeScreen : ScreenView { }
}
